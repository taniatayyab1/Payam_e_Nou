/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow strict-local
 */

import React, {useEffect} from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createDrawerNavigator} from '@react-navigation/drawer';
import MainTabScreen from './screens/TabScreen';
import {DrawerContent} from './screens/DrawerContent';
import RootStackScreen from './screens/RootStackScreen';
import {AuthContext} from './components/context';
import {View} from 'react-native-animatable';
import {ActivityIndicator} from 'react-native-paper';
import FlashMessage, {showMessage} from 'react-native-flash-message';
import {signInToServer, signUpToServer, updateProfile} from './services/authservice';
import AsyncStorage from '@react-native-community/async-storage';
import {
  getUserVideos,
  getCategories,
  uploadUserVideo,
} from './services/videoservice';
import {getUserArticles, uploadArticle} from './services/articleservice';

const Drawer = createDrawerNavigator();

const App = () => {
  const initialLoginState = {
    isLoading: true,
    email: null,
    isLoggedIn: false,
  };

  const loginReducer = (prevState, action) => {
    switch (action.type) {
      case 'RETRIEVE_STATE':
        return {
          ...prevState,
          isLoggedIn: action.status,
          user: action.user,
          isLoading: false,
        };
      case 'LOGIN':
        return {
          ...prevState,
          user: action.user,
          isLoggedIn: action.status,
          isLoading: false,
        };
      case 'LOGOUT':
        return {
          ...prevState,
          user: null,
          isLoggedIn: false,
          isLoading: false,
        };
      case 'REGISTER':
        return {
          ...prevState,
          user: null,
          isLoggedIn: false,
          isLoading: false,
        };
    }
  };

  const [loginState, dispatch] = React.useReducer(
    loginReducer,
    initialLoginState,
  );

  const authContext = React.useMemo(
    () => ({
      signIn: async (email, password) => {
        let isLoggedIn = false;

        try {
          const user = await signInToServer(email, password);
          console.log('user', user);
          if (!user.error) {
            isLoggedIn = true;
            await AsyncStorage.setItem('isLoggedIn', String(isLoggedIn));
            await AsyncStorage.setItem('user', JSON.stringify(user));
          } else {
            showMessage({
              message: user.error,
              type: 'danger',
            });
          }

          dispatch({type: 'LOGIN', user: user, status: isLoggedIn});
        } catch (e) {
          console.log(e);
        }
      },
      signOut: async () => {
        try {
          await AsyncStorage.setItem('isLoggedIn', String(false));
        } catch (e) {
          console.log(e);
        }
        dispatch({type: 'LOGOUT'});
      },
      signUp: async (data) => {
        console.log(data);
        const res = await signUpToServer(data);

        if (res.error) {
          showMessage({
            message: res.error,
            type: 'danger',
          });
        } else {
          showMessage({
            message: 'Thanks! You have been registered.',
            type: 'success',
          });
          dispatch({type: 'REGISTER', id: data.email});
        }
      },
      updateProfile: async (data) => {
        const res = await updateProfile(data);

        if (res.error) {
          showMessage({
            message: res.error,
            type: 'danger',
          });
        } else {
          showMessage({
            message: 'Thanks! You have been registered.',
            type: 'success',
          });
        }
      },
      retrieve: async () => {
        let userStr = await AsyncStorage.getItem('user');
        return JSON.parse(userStr);
      },
      getCategories: async () => {
        return getCategories();
      },
      getUserVideos: async (user) => {
        return await getUserVideos(user);
      },
      upload: async (video, category, user, videoTitle) => {
        return await uploadUserVideo(video, category, user, videoTitle);
      },
      getUserArticles: async (user) => {
        return await getUserArticles(user);
      },
      uploadArticle: async (title, subTitle, description, image, categoryId, userId) => {
        return await uploadArticle(title, subTitle, description, image, categoryId, userId);
      },
    }),
    [],
  );

  useEffect(() => {
    setTimeout(() => {
      AsyncStorage.getItem('isLoggedIn', async (err, isLoggedIn) => {
        let userStr = await AsyncStorage.getItem('user');
        let user = JSON.parse(userStr);
        dispatch({
          type: 'RETRIEVE_STATE',
          status: isLoggedIn === 'true',
          user: user,
        });
      });
    }, 1000);
  }, []);

  if (loginState.isLoading) {
    return (
      <View style={{flex: 1, justifyContent: 'center', alignItems: 'center'}}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  return (
    <AuthContext.Provider value={authContext}>
      <NavigationContainer>
        {loginState.isLoggedIn ? (
          <Drawer.Navigator
            drawerContent={(props) => <DrawerContent {...props} />}>
            <Drawer.Screen name="HomeDrawer" component={MainTabScreen} />
          </Drawer.Navigator>
        ) : (
          <RootStackScreen />
        )}
        <FlashMessage position="bottom" duration={5000} />
      </NavigationContainer>
    </AuthContext.Provider>
  );
};

export default App;
