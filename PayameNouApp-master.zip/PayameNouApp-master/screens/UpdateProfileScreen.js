import React, {useEffect, useState} from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  TextInput,
  Platform,
  StyleSheet,
  StatusBar,
  Alert,
} from 'react-native';
import * as Animatable from 'react-native-animatable';
import LinearGradient from 'react-native-linear-gradient';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Feather from 'react-native-vector-icons/Feather';
import {showMessage} from 'react-native-flash-message';
import {AuthContext} from '../components/context';
import Spinner from 'react-native-loading-spinner-overlay';
import {useIsFocused} from '@react-navigation/native';

const UpdateProfileScreen = ({navigation}) => {
  const [data, setData] = React.useState({
    email: '',
    name: '',
    phone: '',
    check_textInputChange: false,
    isValidEmail: true,
  });
  const isFocused = useIsFocused();

  useEffect(() => {
    retrieve().then((user) => {
      setData({
        email: user.email,
        name: user.name,
        phone: user.contact_number,
      });
    });
  }, [navigation.props, isFocused]);

  const {retrieve, updateProfile} = React.useContext(AuthContext);
  const [isLoading, setIsloading] = useState(false);

  const textInputChange = (val) => {
    if (validateEmail(val.trim())) {
      setData({
        ...data,
        email: val,
        check_textInputChange: true,
        isValidEmail: true,
      });
    } else {
      setData({
        ...data,
        email: val,
        check_textInputChange: false,
        isValidEmail: false,
      });
    }
  };

  const handleValidEmail = (val) => {
    if (validateEmail(val.trim())) {
      setData({
        ...data,
        isValidEmail: true,
      });
    } else {
      setData({
        ...data,
        isValidEmail: false,
      });
    }
  };

  const nameInputChange = (val) => {
    setData({
      ...data,
      name: val,
    });
  };

  const phoneInputChange = (val) => {
    setData({
      ...data,
      phone: val,
    });
  };

  const handlePasswordChange = (val) => {
    if (val.trim().length >= 4) {
      setData({
        ...data,
        password: val,
        isValidPassword: true,
      });
    } else {
      setData({
        ...data,
        password: val,
        isValidPassword: false,
      });
    }
  };

  const handleConfirmPasswordChange = (val) => {
    if (val.trim().length >= 4) {
      setData({
        ...data,
        confirm_password: val,
      });
    } else {
      setData({
        ...data,
        confirm_password: val,
      });
    }
  };

  const updateSecureTextEntry = () => {
    setData({
      ...data,
      secureTextEntry: !data.secureTextEntry,
    });
  };

  const updateConfirmSecureTextEntry = () => {
    setData({
      ...data,
      confirm_secureTextEntry: !data.confirm_secureTextEntry,
    });
  };

  const validateEmail = (text) => {
    let reg = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    return reg.test(text);
  };

  const handleSignUp = async (data) => {
    if (!data.name || !data.email || !data.phone) {
      showMessage({
        message: 'Please fill out all the fields',
        type: 'danger',
      });
      return;
    }
    if (!validateEmail(data.email.trim())) {
      showMessage({
        message: 'Please enter correct email',
        type: 'danger',
      });
      return;
    }
    if (data.password !== data.confirm_password) {
      showMessage({
        message: "Passwords don't match",
        type: 'danger',
      });
      return;
    }

    setIsloading(true);

    await updateProfile(data);

    setIsloading(false);
  };

  return (
    <View style={styles.container}>
      <Spinner
        visible={isLoading}
        textContent={'Loading...'}
        textStyle={styles.spinnerTextStyle}
      />
      <StatusBar backgroundColor="#009387" barStyle="light-content" />
      <View style={styles.header}>
        <Text style={styles.text_header}>Update Profile!</Text>
      </View>
      <Animatable.View animation="fadeInUpBig" style={styles.footer}>
        <Text style={styles.text_footer}>Name</Text>
        <View style={styles.action}>
          <FontAwesome name="quote-left" color="#05375a" size={20} />
          <TextInput
            placeholder="Your Name"
            placeholderTextColor="#666666"
            style={[
              styles.textInput,
              {
                color: '#05375a',
              },
            ]}
            autoCapitalize="none"
            value={data.name}
            onChangeText={(val) => nameInputChange(val)}
          />
        </View>
        <Text
          style={[
            styles.text_footer,
            {
              marginTop: 10,
            },
          ]}>
          Email
        </Text>
        <View style={styles.action}>
          <FontAwesome name="user-o" color="#05375a" size={20} />
          <TextInput
            placeholder="Your Email"
            placeholderTextColor="#666666"
            style={[
              styles.textInput,
              {
                color: '#05375a',
              },
            ]}
            autoCapitalize="none"
            value={data.email}
            onChangeText={(val) => textInputChange(val)}
            onEndEditing={(e) => handleValidEmail(e.nativeEvent.text)}
          />
          {data.check_textInputChange ? (
            <Animatable.View animation="bounceIn">
              <Feather name="check-circle" color="green" size={20} />
            </Animatable.View>
          ) : null}
        </View>
        {data.isValidEmail ? null : (
          <Animatable.View animation="fadeInLeft" duration={500}>
            <Text style={styles.errorMsg}>
              Email must be in correct format.
            </Text>
          </Animatable.View>
        )}

        <Text
          style={[
            styles.text_footer,
            {
              marginTop: 10,
            },
          ]}>
          Phone
        </Text>
        <View style={styles.action}>
          <FontAwesome name="phone" color="#05375a" size={20} />
          <TextInput
            placeholder="Your Phone Number"
            placeholderTextColor="#666666"
            style={[
              styles.textInput,
              {
                color: '#05375a',
              },
            ]}
            value={data.phone}
            autoCapitalize="none"
            onChangeText={(val) => phoneInputChange(val)}
          />
        </View>
        <View style={styles.button}>
          <TouchableOpacity
            style={styles.signIn}
            onPress={() => handleSignUp(data)}>
            <LinearGradient
              colors={['#08d4c4', '#01ab9d']}
              style={styles.signIn}>
              <Text
                style={[
                  styles.textSign,
                  {
                    color: '#fff',
                  },
                ]}>
                Update
              </Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </Animatable.View>
    </View>
  );
};

export default UpdateProfileScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#009387',
  },
  header: {
    flex: 1,
    justifyContent: 'flex-end',
    paddingHorizontal: 20,
    paddingBottom: 50,
  },
  footer: {
    flex: 8,
    backgroundColor: '#fff',
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    paddingHorizontal: 20,
    paddingVertical: 30,
  },
  text_header: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 30,
  },
  text_footer: {
    color: '#05375a',
    fontSize: 18,
  },
  action: {
    flexDirection: 'row',
    marginTop: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f2f2f2',
    paddingBottom: 5,
  },
  actionError: {
    flexDirection: 'row',
    marginTop: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#FF0000',
    paddingBottom: 5,
  },
  textInput: {
    flex: 1,
    marginTop: Platform.OS === 'ios' ? 0 : -12,
    paddingLeft: 10,
    color: '#05375a',
  },
  errorMsg: {
    color: '#FF0000',
    fontSize: 14,
  },
  button: {
    alignItems: 'center',
    marginTop: 30,
  },
  signIn: {
    width: '100%',
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
  },
  textSign: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});
