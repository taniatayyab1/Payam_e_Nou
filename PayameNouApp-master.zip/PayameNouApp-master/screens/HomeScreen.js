import {
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import LinearGradient from 'react-native-linear-gradient';
import {AuthContext} from '../components/context';
import * as Animatable from 'react-native-animatable';
import {useTheme} from '@react-navigation/native';

const HomeScreen = ({navigation}) => {
  const {retrieve} = React.useContext(AuthContext);
  const [user, setUser] = useState({});
  const {colors} = useTheme();

  useEffect(() => {
    retrieve().then((user) => {
      setUser(user);
    });
  }, []);

  return (
    <View style={styles.container}>
      <StatusBar backgroundColor="#009387" barStyle="light-content" />
      <Animatable.View
        style={[styles.welcomeContainer]}
        animation="fadeInUpBig">
        <View>
          <Text style={[styles.suptitle]}>Welcome {user.name}</Text>
          <Text style={[styles.title]}>Share videos with everyone!</Text>
          <View style={styles.button}>
            <TouchableOpacity
              style={styles.uploadVideoBtn}
              onPress={() => navigation.navigate('Upload Video')}>
              <LinearGradient
                colors={['#08d4c4', '#01ab9d']}
                style={styles.uploadVideoBtn}>
                <Text
                  style={[
                    styles.textBtn,
                    {
                      color: '#fff',
                    },
                  ]}>
                  Get Started
                </Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </View>
      </Animatable.View>
    </View>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#009387',
    paddingLeft: 30,
    paddingRight: 30,
  },
  welcomeContainer: {
    width: '100%',
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    backgroundColor: '#009387',
  },
  uploadVideoBtn: {
    width: '100%',
    minWidth: '60%',
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
    alignSelf: 'flex-end',
  },
  textBtn: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  footer: {},
  title: {
    color: '#ffffff',
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 30,
  },
  suptitle: {
    color: '#ffffff',
    fontSize: 18,
    marginBottom: 20,
    textTransform: 'capitalize',
  },
});
