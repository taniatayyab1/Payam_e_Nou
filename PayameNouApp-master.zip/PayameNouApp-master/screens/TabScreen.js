import React from 'react';
import Icon from 'react-native-vector-icons/Ionicons';
import HomeScreen from './HomeScreen';
import {createStackNavigator} from '@react-navigation/stack';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import UserVideosScreen from './UserVideosScreen';
import LinearGradient from 'react-native-linear-gradient';
import {StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import UserArticlesScreen from './UserArticlesScreen';
import UploadVideoScreen from './UploadVideoScreen';
import UploadArticleScreen from './UploadArticleScreen';
import UpdateProfileScreen from './UpdateProfileScreen';

const HomeStack = createStackNavigator();
const UserVideosStack = createStackNavigator();
const UserArticlesStack = createStackNavigator();
const UserProfileStack = createStackNavigator();
const Tab = createBottomTabNavigator();

const MainTabScreen = () => (
  <Tab.Navigator
    initialRouteName="Home"
    tabBarOptions={{
      activeTintColor: '#fff',
      activeBackgroundColor: '#009387',
      inactiveBackgroundColor: '#009387',
      inactiveTintColor: '#bbb',
    }}>
    <Tab.Screen
      name="Home"
      component={HomeStackScreen}
      options={{
        tabBarLabel: 'Home',
        tabBarIcon: ({color, size}) => (
          <Icon name="home" color={color} size={size} />
        ),
      }}
    />
    <Tab.Screen
      name="Videos"
      component={UserVideosStackScreen}
      options={{
        tabBarLabel: 'Videos',
        tabBarIcon: ({color, size}) => (
          <Icon name="videocam" color={color} size={size} />
        ),
      }}
    />
    <Tab.Screen
      name="Articles"
      component={UserArticlesStackScreen}
      options={{
        tabBarLabel: 'Articles',
        tabBarIcon: ({color, size}) => (
          <Icon name="md-reader" color={color} size={size} />
        ),
      }}
    />
    <Tab.Screen
      name="Profile"
      component={UpdateProfileStackScreen}
      options={{
        tabBarLabel: 'Profile',
        tabBarIcon: ({color, size}) => (
          <Icon name="settings" color={color} size={size} />
        ),
      }}
    />
  </Tab.Navigator>
);

export default MainTabScreen;

const HomeStackScreen = ({navigation}) => (
  <HomeStack.Navigator
    screenOptions={{
      headerStyle: {
        backgroundColor: '#009387',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
    }}>
    <HomeStack.Screen
      name="Home"
      component={HomeScreen}
      options={{
        title: 'Dashboard',
        headerLeft: () => (
          <Icon.Button
            name="menu"
            size={25}
            backgroundColor="#009387"
            onPress={() => navigation.openDrawer()}
          />
        ),
      }}
    />
  </HomeStack.Navigator>
);

const UserArticlesStackScreen = ({navigation}) => (
  <UserArticlesStack.Navigator
    initialRouteName="Articles"
    screenOptions={{
      headerStyle: {
        backgroundColor: '#009387',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
    }}>
    <UserArticlesStack.Screen
      name="Articles"
      component={UserArticlesScreen}
      options={{
        title: 'Articles',
        headerLeft: () => (
          <Icon.Button
            name="chevron-back"
            size={25}
            backgroundColor="#009387"
            onPress={() => navigation.goBack(null)}
          />
        ),
        headerRight: () => (
          <View style={{flexDirection: 'row'}}>
            <TouchableOpacity
              style={styles.uploadVideoBtn}
              onPress={() => navigation.navigate('Upload Article')}>
              <LinearGradient
                colors={['#08d4c4', '#01ab9d']}
                style={styles.uploadVideoBtn}>
                <Text
                  style={[
                    styles.textBtn,
                    {
                      color: '#fff',
                    },
                  ]}>
                  Add Article
                </Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        ),
      }}
    />
    <UserArticlesStack.Screen
      name="Upload Article"
      component={UploadArticleScreen}
      options={{
        title: 'Upload Article',
        headerLeft: () => (
          <Icon.Button
            name="chevron-back"
            size={25}
            backgroundColor="#009387"
            onPress={() =>
              navigation.navigate('Articles', {
                screen: 'Articles',
                initial: false,
              })
            }
          />
        ),
      }}
    />
  </UserArticlesStack.Navigator>
);

const UserVideosStackScreen = ({navigation}) => (
  <UserVideosStack.Navigator
    initialRouteName="Videos"
    screenOptions={{
      headerStyle: {
        backgroundColor: '#009387',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
    }}>
    <UserVideosStack.Screen
      name="Videos"
      component={UserVideosScreen}
      options={{
        title: 'Videos',
        headerLeft: () => (
          <Icon.Button
            name="chevron-back"
            size={25}
            backgroundColor="#009387"
            onPress={() => navigation.goBack(null)}
          />
        ),
        headerRight: () => (
          <View style={{flexDirection: 'row'}}>
            <TouchableOpacity
              style={styles.uploadVideoBtn}
              onPress={() => navigation.navigate('Upload Video')}>
              <LinearGradient
                colors={['#08d4c4', '#01ab9d']}
                style={styles.uploadVideoBtn}>
                <Text
                  style={[
                    styles.textBtn,
                    {
                      color: '#fff',
                    },
                  ]}>
                  Add Video
                </Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        ),
      }}
    />
    <UserVideosStack.Screen
      name="Upload Video"
      component={UploadVideoScreen}
      options={{
        title: 'Upload Video',
        headerLeft: () => (
          <Icon.Button
            name="chevron-back"
            size={25}
            backgroundColor="#009387"
            onPress={() =>
              navigation.navigate('Videos', {
                screen: 'Videos',
                initial: false,
              })
            }
          />
        ),
      }}
    />
  </UserVideosStack.Navigator>
);

const UpdateProfileStackScreen = ({navigation}) => (
  <UserProfileStack.Navigator
    screenOptions={{
      headerStyle: {
        backgroundColor: '#009387',
      },
      headerTintColor: '#fff',
      headerTitleStyle: {
        fontWeight: 'bold',
      },
    }}>
    <UserProfileStack.Screen
      name="Home"
      component={UpdateProfileScreen}
      options={{
        title: 'Settings',
        headerLeft: () => (
          <Icon.Button
            name="chevron-back"
            size={25}
            backgroundColor="#009387"
            onPress={() => {
              navigation.goBack();
            }}
          />
        ),
      }}
    />
  </UserProfileStack.Navigator>
);

const styles = StyleSheet.create({
  uploadVideoBtn: {
    width: 120,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 5,
    alignSelf: 'center',
    marginRight: 50,
  },
  textBtn: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});
