import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import React, {useEffect, useState} from 'react';
import {AuthContext} from '../components/context';
import LinearGradient from 'react-native-linear-gradient';
import ImagePicker from 'react-native-image-picker';
import {showMessage} from 'react-native-flash-message';
import Spinner from 'react-native-loading-spinner-overlay';
import Video from 'react-native-video';
import {Picker} from '@react-native-community/picker';

const UploadVideoScreen = ({navigation}) => {
  const {retrieve, getCategories, upload} = React.useContext(AuthContext);
  const [user, setUser] = useState({});
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [selectedVideo, setSelectedVideo] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [videoTitle, setVideoTitle] = useState(null);

  const clearState = () => {
    setSelectedCategory(null);
    setSelectedVideo(null);
    setVideoTitle(null);
  };

  useEffect(() => {
    retrieve().then((user) => {
      setUser(user);
    });
    getCategories().then((categories) => {
      if (categories.data) {
        console.log(categories.data);
        setCategories(categories.data);
      }
    });
  }, []);

  const selectVideo = () => {
    const options = {
      title: 'Select video',
      mediaType: 'video',
      path: 'video',
      videoQuality: 'high',
    };

    ImagePicker.showImagePicker(options, (response) => {
      if (response.uri) {
        setSelectedVideo(response);
      }
    });
  };

  const setTitle = (title) => {
    setVideoTitle(capitalize(title.trim()));
  };

  const capitalize = (s) => {
    if (typeof s !== 'string') {return '';}
    return s.charAt(0).toUpperCase() + s.slice(1);
  };

  const uploadVideo = () => {
    if (!selectedCategory) {
      showMessage({
        message: 'Please select category',
        type: 'danger',
      });
      return;
    }
    if (!selectedVideo) {
      showMessage({
        message: 'Please select video to upload',
        type: 'danger',
      });
      return;
    }
    if (!videoTitle) {
      showMessage({
        message: 'Please enter video title',
        type: 'danger',
      });
      return;
    }

    setIsUploading(true);

    upload(selectedVideo, selectedCategory, user, videoTitle).then(
      (response) => {
        setIsUploading(false);
        if (response.error) {
          showMessage({
            message: 'Uploading failed',
            type: 'danger',
          });
        } else {
          showMessage({
            message: 'Congratulations! Video uploaded.',
            type: 'success',
            duration: 8000,
          });
          clearState();
          navigation.navigate('Videos');
        }
      },
      () => {
        setIsUploading(false);
        showMessage({
          message: 'Uploading failed',
          type: 'danger',
        });
      },
    );
  };

  return (
    <View style={styles.container}>
      <Spinner
        visible={isUploading}
        textContent={'Uploading...'}
        textStyle={styles.spinnerTextStyle}
      />
      <View style={styles.columnFields}>
        <View style={styles.columnField}>
          <Text
            style={[
              styles.text_footer,
              {
                marginTop: 10,
              },
            ]}>
            Category
          </Text>
          <View style={styles.picker_container}>
            <Picker
              style={styles.action}
              selectedValue={selectedCategory}
              onValueChange={(itemValue, itemIndex) =>
                setSelectedCategory(itemValue)
              }>
              {categories.map((category, id) => {
                return (
                  <Picker.Item
                    key={category._id}
                    value={category._id}
                    label={category.name}
                  />
                );
              })}
            </Picker>
          </View>
        </View>
        <View style={styles.columnFieldLast}>
          <Text
            style={[
              styles.text_footer,
              {
                marginTop: 10,
              },
            ]}>
            Video
          </Text>
          <View style={styles.button}>
            <TouchableOpacity
              onPress={() => selectVideo()}
              style={[
                styles.signIn,
                {
                  borderColor: '#009387',
                  borderWidth: 1,
                  marginTop: 10,
                },
              ]}>
              <Text
                style={[
                  styles.textSign,
                  {
                    color: '#009387',
                  },
                ]}>
                Select
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
      <Text
        style={[
          styles.text_footer,
          {
            marginTop: 10,
          },
        ]}>
        Title
      </Text>
      <View>
        <TextInput
          placeholder="Video Title"
          placeholderTextColor="#666666"
          style={[
            styles.picker_container,
            {
              color: '#05375a',
            },
          ]}
          autoCapitalize="none"
          onChangeText={(val) => setTitle(val)}
        />
      </View>
      {selectedVideo ? (
        <Video
          source={{uri: selectedVideo.uri}}
          controls={true}
          resizeMode="contain"
          style={styles.backgroundVideo}
        />
      ) : null}
      <View style={styles.button}>
        <TouchableOpacity
          style={styles.signIn}
          onPress={() => {
            uploadVideo();
          }}>
          <LinearGradient colors={['#08d4c4', '#01ab9d']} style={styles.signIn}>
            <Text
              style={[
                styles.textSign,
                {
                  color: '#fff',
                },
              ]}>
              Upload
            </Text>
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default UploadVideoScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingLeft: 20,
    paddingRight: 20,
  },
  picker_container: {
    borderColor: '#009387',
    borderWidth: 1,
    marginTop: 10,
    borderRadius: 10,
  },
  picker: {
    fontSize: 18,
    color: '#05375a',
  },
  text_footer: {
    color: '#05375a',
    fontSize: 18,
  },
  action: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    paddingBottom: 5,
    color: '#05375a',
  },
  signIn: {
    width: '100%',
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    marginTop: 20,
    alignSelf: 'flex-end',
  },
  textSign: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  videoText: {
    fontStyle: 'italic',
    marginTop: 20,
    color: 'green',
  },
  spinnerTextStyle: {
    color: '#FFF',
  },
  backgroundVideo: {
    height: '30%',
    marginTop: 30,
  },
  columnFields: {
    flexDirection: 'row',
  },
  columnField: {
    width: '50%',
  },
  columnFieldLast: {
    width: '40%',
    marginLeft: '10%',
  },
});
