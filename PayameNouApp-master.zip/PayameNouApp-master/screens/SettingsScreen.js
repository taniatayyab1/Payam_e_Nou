import {Button, Text, View, StyleSheet} from "react-native";
import React from "react";

const SettingsScreen = () => {
    return (
        <View style={Styles.container}>
            <Text>Settings Screen</Text>
        </View>
    );
};

export default SettingsScreen;

const Styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
    }
});
