import React, {useEffect, useState} from 'react';
import {AuthContext} from '../components/context';
import {FlatList, StyleSheet, Text, View} from 'react-native';
import Spinner from 'react-native-loading-spinner-overlay';
import {Image} from 'react-native-animatable';
import Icon from 'react-native-vector-icons/Ionicons';
import moment from 'moment';
import {useIsFocused} from '@react-navigation/native';

const UserVideosScreen = ({navigation}) => {
  const {retrieve, getUserVideos} = React.useContext(AuthContext);
  const [user, setUser] = useState({});
  const [videos, setVideos] = useState([]);
  const [isloading, setIsLoading] = useState(false);
  const isFocused = useIsFocused();

  useEffect(() => {
    reloadVideos();
  }, [navigation.props, isFocused]);

  const reloadVideos = () => {
    retrieve().then((user) => {
      setIsLoading(true);
      setUser(user);
      getUserVideos(user).then(
        (videos) => {
          console.log(videos);
          if (videos) {
            videos.map((video) => {
              video.thumbnail = JSON.parse(video.thumbnail).replace(
                /['"]+/g,
                '',
              );
              video.submitDate = moment(video.createdAt).format('lll');
            });
            setVideos(videos);
            setIsLoading(false);
          }
        },
        (e) => {
          console.log(e);
        },
      );
    });
  };

  return (
    <View style={styles.container}>
      <Spinner
        visible={isloading}
        textContent={'Loading...'}
        textStyle={styles.spinnerTextStyle}
      />
      <View style={styles.reloadBtn}>
        <Icon.Button
          name="reload"
          size={25}
          backgroundColor="#009387"
          onPress={() => reloadVideos()}
        />
      </View>
      <FlatList
        data={videos}
        keyExtractor={(item) => item._id}
        renderItem={({item}) => (
          <View style={styles.rowViewContainer}>
            <Image
              style={styles.thumbnail}
              source={{
                uri: `data:image/jpeg;base64,${item.thumbnail}`,
              }}
            />
            <View style={styles.columnViewContainer}>
              <Text style={styles.title} ellipsizeMode="tail" numberOfLines={1}>
                {item.title}
              </Text>
              <Text style={styles.title}>
                {item.category_id.name}
              </Text>

              <View style={styles.coulmnFooterContainer}>
                <Text style={styles.date}>{item.submitDate}</Text>
                <Text style={styles.status}>
                  Status:{' '}
                  {item.is_active === '0' && (
                    <Text style={styles.statusBold}>Pending</Text>
                  )}
                  {item.is_active === '1' && (
                    <Text style={styles.statusBoldGreen}>Approved</Text>
                  )}
                  {item.is_active === '2' && (
                    <Text style={styles.statusBoldRed}>Rejected</Text>
                  )}
                </Text>
              </View>
            </View>
          </View>
        )}
      />
    </View>
  );
};

export default UserVideosScreen;

const styles = StyleSheet.create({
  spinnerTextStyle: {
    color: '#FFF',
  },
  text_footer: {
    color: '#05375a',
    fontSize: 18,
  },
  container: {
    flex: 1,
    position: 'relative',
  },
  separator: {
    height: 0.5,
    width: '100%',
    backgroundColor: '#000',
  },
  rowViewContainer: {
    flex: 1,
    paddingRight: 15,
    paddingTop: 13,
    paddingBottom: 13,
    borderBottomWidth: 0.5,
    borderColor: '#c9c9c9',
    flexDirection: 'row',
    alignItems: 'center',
    fontSize: 20,
    marginLeft: 10,
    color: '#05375a',
  },
  columnViewContainer: {
    color: '#05375a',
    padding: 10,
    paddingTop: 0,
  },
  date: {
    color: '#05375a',
  },
  title: {
    fontSize: 16,
    // fontWeight: 'bold',
    color: '#05375a',
    width: 250,
  },
  thumbnail: {
    width: 100,
    height: 70,
  },
  coulmnFooterContainer: {
    flex: 1,
  },
  status: {
    color: '#05375a',
  },
  statusBold: {
    fontWeight: 'bold',
    textTransform: 'uppercase',
    color: '#05375a',
  },
  statusBoldGreen: {
    fontWeight: 'bold',
    textTransform: 'uppercase',
    color: '#488248',
  },
  statusBoldRed: {
    fontWeight: 'bold',
    textTransform: 'uppercase',
    color: '#af1919',
  },
  reloadBtn: {
    position: 'absolute',
    right: 5,
    top: -48,
    zIndex: 9999,
  },
});
