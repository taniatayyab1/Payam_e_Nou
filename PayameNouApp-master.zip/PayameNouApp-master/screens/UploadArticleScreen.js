import React, {useEffect, useState} from 'react';
import {
  View,
  TextInput,
  StyleSheet,
  Text,
  TouchableOpacity,
} from 'react-native';
import {AuthContext} from '../components/context';
import ImagePicker from 'react-native-image-picker';
import {showMessage} from 'react-native-flash-message';
import Spinner from 'react-native-loading-spinner-overlay';
import {Picker} from '@react-native-community/picker';
import Modal from 'react-native-modal';
import Icon from 'react-native-vector-icons/Ionicons';
import {Image} from 'react-native-animatable';
import LinearGradient from 'react-native-linear-gradient';

const UploadArticleScreen = ({navigation}) => {
  const {retrieve, getCategories, uploadArticle} = React.useContext(
    AuthContext,
  );
  const [user, setUser] = useState({});
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [title, setTitle] = useState(null);
  const [subTitle, setSubTitle] = useState(null);
  const [description, setDescription] = useState(null);
  const [image, setImage] = useState(null);
  const [isModalVisible, setIsModalVisible] = useState(false);

  const clearState = () => {
    setTitle(null);
    setSubTitle(null);
    setDescription(null);
    setImage(null);
  };

  useEffect(() => {
    retrieve().then((user) => {
      setUser(user);
    });
    getCategories().then((categories) => {
      if (categories.data) {
        console.log(categories.data);
        setCategories(categories.data);
      }
    });
  }, []);

  const selectImage = () => {
    const options = {
      title: 'Select Image',
      mediaType: 'photo',
      path: 'video',
      quality: 0.5,
      saveToPhotos: true,
    };

    ImagePicker.showImagePicker(options, (response) => {
      console.log(response);
      if (response.uri) {
        setImage(response);
      }
    });
  };

  const capitalize = (s) => {
    if (typeof s !== 'string') {
      return '';
    }
    return s.charAt(0).toUpperCase() + s.slice(1);
  };

  const setArticleTitle = (title) => {
    setTitle(capitalize(title.trim()));
  };

  const setArticleSubTitle = (title) => {
    setSubTitle(capitalize(title.trim()));
  };

  const setArticleDesc = (title) => {
    setDescription(capitalize(title.trim()));
  };

  const toggleModal = () => {
    setIsModalVisible(!isModalVisible);
  };

  const submitArticle = () => {
    if (!title) {
      showMessage({
        message: 'Please enter article title',
        type: 'danger',
      });
      return;
    }
    if (!subTitle) {
      showMessage({
        message: 'Please enter article sub title',
        type: 'danger',
      });
      return;
    }
    if (!description) {
      showMessage({
        message: 'Please enter article description',
        type: 'danger',
      });
      return;
    }
    if (!image) {
      showMessage({
        message: 'Please select image for article',
        type: 'danger',
      });
      return;
    }

    setIsUploading(true);

    uploadArticle(title, subTitle, description, image, selectedCategory, user._id).then(
      (response) => {
        setIsUploading(false);
        if (response.error) {
          showMessage({
            message: 'Submission failed',
            type: 'danger',
          });
        } else {
          showMessage({
            message: 'Congratulations! article submitted.',
            type: 'success',
            duration: 8000,
          });
          clearState();
          navigation.navigate('Articles');
        }
      },
      () => {
        setIsUploading(false);
        showMessage({
          message: 'Submission failed',
          type: 'danger',
        });
      },
    );
  };

  return (
    <View style={styles.container}>
      <Spinner
        visible={isUploading}
        textContent={'Uploading...'}
        textStyle={styles.spinnerTextStyle}
      />
      <Text
        style={[
          styles.text_footer,
          {
            marginTop: 10,
          },
        ]}>
        Category
      </Text>
      <View style={styles.picker_container}>
        <Picker
          style={styles.action}
          selectedValue={selectedCategory}
          onValueChange={(itemValue, itemIndex) =>
            setSelectedCategory(itemValue)
          }>
          {categories.map((category, id) => {
            return (
              <Picker.Item
                key={category._id}
                value={category._id}
                label={category.name}
              />
            );
          })}
        </Picker>
      </View>
      <Text
        style={[
          styles.text_footer,
          {
            marginTop: 10,
          },
        ]}>
        Title
      </Text>
      <View>
        <TextInput
          placeholder="Title"
          placeholderTextColor="#666666"
          style={[styles.picker_container]}
          autoCapitalize="none"
          onChangeText={(val) => setArticleTitle(val)}
        />
      </View>
      <Text
        style={[
          styles.text_footer,
          {
            marginTop: 10,
          },
        ]}>
        Sub Title
      </Text>
      <TextInput
        multiline={true}
        numberOfLines={2}
        style={styles.picker_container}
        onChangeText={(val) => setArticleSubTitle(val)}
      />
      <View style={styles.button}>
        <TouchableOpacity onPress={() => toggleModal()} style={[styles.signIn]}>
          <Text
            style={[
              styles.textSign,
              {
                color: '#009387',
              },
            ]}>
            Add Description
          </Text>
        </TouchableOpacity>
      </View>
      <Modal isVisible={isModalVisible}>
        <View style={styles.modal}>
          <Text style={[styles.text_footer]}>Description</Text>
          <TextInput
            multiline={true}
            numberOfLines={10}
            style={[
              styles.picker_container,
              {height: '70%', textAlignVertical: 'top', marginTop: 10},
            ]}
            onChangeText={(val) => setArticleDesc(val)}
          />
          <TouchableOpacity
            onPress={() => toggleModal()}
            style={[styles.signIn]}>
            <Text
              style={[
                styles.textSign,
                {
                  color: '#009387',
                },
              ]}>
              Done
            </Text>
          </TouchableOpacity>
        </View>
      </Modal>
      <Text
        style={[
          styles.text_footer,
          {
            marginTop: 10,
          },
        ]}>
        Image
      </Text>
      <View style={styles.imageContainer}>
        <View style={styles.imageAdd}>
          <Icon.Button
            name="md-add-outline"
            size={50}
            backgroundColor="#009387"
            onPress={() => selectImage()}
          />
        </View>
        {image && (
          <View style={styles.imageAdd}>
            <Image style={styles.thumbnail} source={{uri: image.uri}} />
          </View>
        )}
      </View>
      <View style={styles.button}>
        <TouchableOpacity
          onPress={() => {
            submitArticle();
          }}>
          <LinearGradient colors={['#08d4c4', '#01ab9d']} style={styles.signIn}>
            <Text
              style={[
                styles.textSign,
                {
                  color: '#fff',
                },
              ]}>
              Submit
            </Text>
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default UploadArticleScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingLeft: 20,
    paddingRight: 20,
  },
  spinnerTextStyle: {
    color: '#FFF',
  },
  text_footer: {
    color: '#05375a',
    fontSize: 18,
  },
  picker_container: {
    color: '#05375a',
    borderColor: '#009387',
    borderWidth: 1,
    marginTop: 10,
    borderRadius: 10,
    paddingLeft: 5,
    paddingRight: 5,
  },
  signIn: {
    width: '100%',
    height: 50,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    alignSelf: 'flex-end',
    borderColor: '#009387',
    borderWidth: 1,
    marginTop: 20,
  },
  modal: {
    flex: 1,
    backgroundColor: '#ffffff',
    borderRadius: 10,
    padding: 20,
  },
  imageAdd: {
    width: 70,
    height: 70,
    marginTop: 10,
    borderRadius: 10,
    marginLeft: 10,
  },
  thumbnail: {
    width: '100%',
    height: '100%',
    borderRadius: 10,
  },
  imageContainer: {
    flexDirection: 'row',
  },
});
