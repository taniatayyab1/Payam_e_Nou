import {API_BASE_URL} from './authservice';

export async function getUserArticles(user) {
  try {
    const userId = encodeURIComponent(JSON.stringify(user._id));
    const url = `${API_BASE_URL}user_articles?user_id=${userId}`;
    let res = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
    });
    let json = await res.json();
    return json;
  } catch (error) {
    console.error(error);
  }
}

export async function uploadArticle(title, subTitle, description, image, categoryId, userId) {
  console.log(title, subTitle, description, image, categoryId, userId);
  try {
    let response = await fetch(API_BASE_URL + 'add-article', {
      method: 'POST',
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      body: createFormData(image, {
        category_id: categoryId,
        user_id: userId,
        title: title,
        sub_title: subTitle,
        description: description,
      }),
    }).catch((err) => {
      console.log(err);
    });
    return await response.json();
  } catch (error) {
    console.log('error : ' + error);
    return {error: error};
  }
}

const createFormData = (image, body) => {
  const data = new FormData();

  data.append('file', {
    name: generateName(8),
    type: 'image/jpeg',
    uri: image.uri,
  });

  Object.keys(body).forEach((key) => {
    data.append(key, body[key]);
  });

  data.append('Content-Type', 'image/jpeg');

  return data;
};

function generateName(length) {
  let result = '';
  const characters =
      'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const charactersLength = characters.length;
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result + '.jpeg';
}
