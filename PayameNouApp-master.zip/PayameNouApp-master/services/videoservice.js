import {API_BASE_URL} from './authservice';
import {ProcessingManager} from 'react-native-video-processing';

export async function getCategories() {
  try {
    let res = await fetch(API_BASE_URL + 'get-categories', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
    });
    let json = await res.json();
    return json;
  } catch (error) {
    console.error(error);
  }
}

export async function getUserVideos(user) {
  try {
    const userId = encodeURIComponent(JSON.stringify(user._id));
    const url = `${API_BASE_URL}user_videos?user_id=${userId}`;
    console.log(userId, url);
    let res = await fetch(url, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
    });
    let json = await res.json();
    return json;
  } catch (error) {
    console.error(error);
  }
}

export async function uploadUserVideo(video, category, user, videoTitle) {
  console.log(video, category, user);

  try {
    const videoData = await compressVideo(video.path);
    console.log('compressed data', videoData);

    let response = await fetch(API_BASE_URL + 'upload', {
      method: 'POST',
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      body: createFormData(videoData, {
        category_id: category,
        user_id: user._id,
        title: videoTitle,
        image_thumbnail: JSON.stringify(videoData.thumbnail),
      }),
    }).catch((err) => {
      console.log(err);
    });
    return await response.json();
  } catch (error) {
    console.log('error : ' + error);
    return {error: error};
  }
}

const createFormData = (video, body) => {
  const data = new FormData();

  data.append('file', {
    name: generateVideoName(8),
    type: 'video/mp4',
    uri: video.path,
  });

  Object.keys(body).forEach((key) => {
    data.append(key, body[key]);
  });

  return data;
};

function generateVideoName(length) {
  let result = '';
  const characters =
    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const charactersLength = characters.length;
  for (let i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result + '.mp4';
}

async function compressVideo(path) {
  console.log(`begin compressing ${path}`);
  try {
    const origin = await ProcessingManager.getVideoInfo(path);
    const result = await ProcessingManager.compress(path, {
      width: origin.size && origin.size.width / 3,
      height: origin.size && origin.size.height / 3,
      bitrateMultiplier: 7,
      minimumBitrate: 300000,
    });
    const thumbnail = await ProcessingManager.getPreviewForSecond(
      result.source,
    );
    return {path: result.source, thumbnail};
  } catch (e) {
    console.log(e);
  }
}
