export const API_BASE_URL = 'https://payam-e-nou.herokuapp.com/api/v1/';
// export const API_BASE_URL = 'http://192.168.8.102:9800/api/v1/';

export async function signInToServer(email, password) {
  try {
    let res = await fetch(API_BASE_URL + 'login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify({
        email: email,
        password: password,
      }),
    });
    let json = await res.json();
    return json;
  } catch (error) {
    console.error(error);
  }
}

export async function signUpToServer(data) {
  try {
    let res = await fetch(API_BASE_URL + 'register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify({
        email: data.email.trim(),
        password: data.password.trim(),
        phone: data.phone.trim(),
        name: data.name.trim(),
      }),
    });
    let json = await res.json();
    return json;
  } catch (error) {
    console.error(error);
  }
}

export async function updateProfile(data) {
  try {
    let res = await fetch(API_BASE_URL + 'update-profile', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify({
        email: data.email.trim(),
        phone: data.phone.trim(),
        name: data.name.trim(),
      }),
    });
    let json = await res.json();
    return json;
  } catch (error) {
    console.error(error);
  }
}
