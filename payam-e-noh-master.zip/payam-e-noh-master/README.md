# Payam-e-noh-Journalism-CMS

Payam-e-Noh Admin Panel

how to start ?

npm install

npm start
